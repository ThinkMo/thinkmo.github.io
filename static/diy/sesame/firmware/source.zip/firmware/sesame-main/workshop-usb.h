#pragma once
#include <Preferences.h>

// Sesame Workshop protocol v1. No motion is triggered by identification or session.
// Commands are @<request-id> <command> followed by a newline. Replies are JSON lines.
extern Servo servos[8];
extern int8_t servoSubtrim[8];
void workshopMove(uint8_t channel, int angle);
void workshopCancel(bool release);
bool workshopPose(const char* name);
void workshopLegacy(const char* command);

bool workshopSession = false;
bool workshopHalted = false;
bool workshopMoving = false;
unsigned long workshopHeartbeat = 0;
bool workshopReading = false;
Preferences workshopPreferences;
bool workshopStorage = false;

void workshopReply(unsigned long id, bool ok, const char* fields = "") {
  Serial.printf("{\"id\":%lu,\"ok\":%s%s}\n", id, ok ? "true" : "false", fields);
}

void workshopTrims(unsigned long id) {
  Serial.printf("{\"id\":%lu,\"ok\":true,\"trims\":[", id);
  for (int i = 0; i < 8; ++i) Serial.printf("%s%d", i ? "," : "", servoSubtrim[i]);
  Serial.println("]}");
}

void workshopInit() {
#ifndef WORKSHOP_TESTER
  workshopStorage = workshopPreferences.begin("sesame-ws", false);
  if (workshopStorage && workshopPreferences.getUChar("version", 0) == 1 &&
      workshopPreferences.getBytesLength("trims") == 8) {
    int8_t saved[8];
    workshopPreferences.getBytes("trims", saved, 8);
    bool valid = true;
    for (int i = 0; i < 8; ++i) if (saved[i] < -90 || saved[i] > 90) valid = false;
    if (valid) memcpy(servoSubtrim, saved, 8);
  }
#endif
}

void workshopStop(bool release) {
  workshopHalted = true;
  workshopCancel(release);
}

void workshopCommand(unsigned long id, const char* command) {
  if (strcmp(command, "hello") == 0) {
#ifdef WORKSHOP_TESTER
    const char* kind = "tester";
#else
    const char* kind = "main";
#endif
    Serial.printf("{\"id\":%lu,\"ok\":true,\"board\":\"lolin_s2_mini\",\"chip\":\"ESP32-S2\",\"protocol\":1,\"kind\":\"%s\",\"version\":\"1.0.0\"}\n", id, kind);
    return;
  }
  if (strcmp(command, "session") == 0) {
    workshopStop(false);
    workshopSession = true;
    workshopHeartbeat = millis();
    workshopReply(id, true);
    return;
  }
  if (strcmp(command, "stop") == 0 || strcmp(command, "release") == 0 || strcmp(command, "end") == 0) {
    workshopStop(strcmp(command, "release") == 0);
    if (strcmp(command, "end") == 0) workshopSession = false;
    workshopReply(id, true);
    return;
  }
  if (!workshopSession) {
    workshopReply(id, false, ",\"error\":\"session_required\"");
    return;
  }
  if (strcmp(command, "ping") == 0) {
    workshopHeartbeat = millis();
    workshopReply(id, true);
    return;
  }
  if (strcmp(command, "trims") == 0) {
    workshopTrims(id);
    return;
  }
  if (workshopMoving) {
    workshopReply(id, false, ",\"error\":\"motion_busy_stop_first\"");
    return;
  }
  int channel, angle;
  char extra;
  if (sscanf(command, "motor %d %d %c", &channel, &angle, &extra) == 2) {
    if (channel < 0 || channel > 7 || angle < 0 || angle > 180) {
      workshopReply(id, false, ",\"error\":\"out_of_range\"");
      return;
    }
    workshopHalted = false;
    workshopMove(channel, angle);
    workshopReply(id, true);
    return;
  }
  if (strcmp(command, "center") == 0) {
    workshopHalted = false;
    for (int i = 0; i < 8 && !workshopHalted; ++i) workshopMove(i, 90);
    workshopReply(id, true);
    return;
  }
#ifndef WORKSHOP_TESTER
  if (sscanf(command, "trim %d %d %c", &channel, &angle, &extra) == 2) {
    if (channel < 0 || channel > 7 || angle < -90 || angle > 90) {
      workshopReply(id, false, ",\"error\":\"out_of_range\"");
      return;
    }
    servoSubtrim[channel] = angle;
    workshopTrims(id);
    return;
  }
  if (strcmp(command, "save") == 0 || strcmp(command, "reset") == 0) {
    if (!workshopStorage) {
      workshopReply(id, false, ",\"error\":\"storage_unavailable\"");
      return;
    }
    if (strcmp(command, "reset") == 0) memset(servoSubtrim, 0, 8);
    bool saved = workshopPreferences.putBytes("trims", servoSubtrim, 8) == 8;
    saved = workshopPreferences.putUChar("version", 1) == 1 && saved;
    if (saved) workshopTrims(id);
    else workshopReply(id, false, ",\"error\":\"storage_write_failed\"");
    return;
  }
  char pose[20];
  if (sscanf(command, "pose %19s %c", pose, &extra) == 1 && workshopPose(pose)) {
    workshopHalted = false;
    workshopReply(id, true, ",\"queued\":true");
    return;
  }
#endif
  workshopReply(id, false, ",\"error\":\"unknown_command\"");
}

void workshopService() {
  if (workshopReading) return;
  workshopReading = true;
  if (workshopSession && millis() - workshopHeartbeat > 1500) {
    workshopSession = false;
    workshopStop(false);
    Serial.println("{\"event\":\"session_timeout\"}");
  }
  static char line[128];
  static size_t used = 0;
  static bool overflow = false;
  while (Serial.available()) {
    char ch = Serial.read();
    if (ch == '\r') continue;
    if (ch == '\n') {
      if (!overflow && used) {
        line[used] = '\0';
        if (line[0] == '@') {
          unsigned long id;
          int consumed = 0;
          if (sscanf(line, "@%lu %n", &id, &consumed) == 1 && consumed > 0) {
            workshopCommand(id, line + consumed);
          }
        } else if (!workshopSession) workshopLegacy(line);
      }
      used = 0;
      overflow = false;
    } else if (used < sizeof(line) - 1 && !overflow) line[used++] = ch;
    else overflow = true;
  }
  workshopReading = false;
}
