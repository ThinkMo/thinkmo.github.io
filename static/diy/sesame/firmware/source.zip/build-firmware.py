"""Build the two S2 Mini sketches and publish NVS-preserving split images.

Requires Arduino CLI, esp32 core 3.3.10, ESP32Servo 3.0.9 and Adafruit OLED libraries.
Run python build-firmware.py --cli /path/to/arduino-cli [--config /path/to/config.yaml].
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
FQBN = 'esp32:esp32:lolin_s2_mini:CDCOnBoot=default,PartitionScheme=default'

def package_builds(build_root, arduino_data):
    release = {'version': '1.0.0', 'board': 'LOLIN S2 Mini', 'chip': 'ESP32-S2',
               'fqbn': FQBN, 'core': '3.3.10', 'ESP32Servo': '3.0.9',
               'hardwareTested': False, 'builds': []}
    output = ROOT / 'dist/firmware'
    output.mkdir(parents=True, exist_ok=True)
    esptool = arduino_data / 'packages/esp32/tools/esptool_py/5.3.0/esptool.exe'
    if not esptool.exists():
        executable = shutil.which('esptool')
        if not executable:
            raise RuntimeError('Provide esptool 5.x on PATH or the installed ESP32 tools directory.')
        esptool = Path(executable)
    boot_app = arduino_data / 'packages/esp32/hardware/esp32/3.3.10/tools/partitions/boot_app0.bin'
    for kind in ['tester', 'main']:
        build = build_root / f'build-{kind}'
        stem = f'sesame-{kind}.ino'
        boot = output / f'{kind}-boot.bin'
        app = output / f'{kind}-app.bin'
        subprocess.run([str(esptool), '--chip', 'esp32s2', 'merge-bin', '-o', str(boot),
                        '--target-offset', '0x1000', '--flash-mode', 'dio', '--flash-freq', '80m', '--flash-size', '4MB',
                        '0x1000', str(build / f'{stem}.bootloader.bin'), '0x8000', str(build / f'{stem}.partitions.bin')], check=True)
        subprocess.run([str(esptool), '--chip', 'esp32s2', 'merge-bin', '-o', str(app),
                        '--target-offset', '0xe000', '--flash-mode', 'dio', '--flash-freq', '80m', '--flash-size', '4MB',
                        '0xe000', str(boot_app), '0x10000', str(build / f'{stem}.bin')], check=True)
        # No write spans the NVS partition [0x9000, 0xe000).
        assert boot.stat().st_size + 0x1000 <= 0x9000
        assert app.stat().st_size + 0xe000 <= 0x150000
        parts = [{'path': boot.name, 'offset': 0x1000}, {'path': app.name, 'offset': 0xe000}]
        manifest = {'name': f'Sesame S2 Mini {kind}', 'version': release['version'],
                    'new_install_prompt_erase': True, 'new_install_improv_wait_time': 0,
                    'builds': [{'chipFamily': 'ESP32-S2', 'parts': parts}]}
        (output / f'{kind}.json').write_text(json.dumps(manifest, indent=2), encoding='utf8')
        files = [{'name': f.name, 'bytes': f.stat().st_size,
                  'sha256': hashlib.sha256(f.read_bytes()).hexdigest()} for f in [boot, app]]
        release['builds'].append({'kind': kind, 'appBytes': (build / f'{stem}.bin').stat().st_size, 'files': files})
    (output / 'release.json').write_text(json.dumps(release, indent=2), encoding='utf8')
    with zipfile.ZipFile(output / 'source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in (ROOT / 'firmware').rglob('*'):
            if path.is_file(): archive.write(path, path.relative_to(ROOT))
        for name in ['build-firmware.py', 'README.md', 'LICENSE']:
            if (ROOT / name).exists(): archive.write(ROOT / name, name)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--cli', default=shutil.which('arduino-cli'))
    parser.add_argument('--config')
    parser.add_argument('--data', default=str(Path(os.environ.get('LOCALAPPDATA', '~/.arduino15')) / 'Arduino15'))
    parser.add_argument('--build-root', default=str(ROOT / '.build'))
    parser.add_argument('--package-only', action='store_true')
    args = parser.parse_args()
    build_root = Path(args.build_root).resolve()
    arduino_data = Path(args.data).expanduser().resolve()
    if not args.package_only:
        if not args.cli: parser.error('Arduino CLI not found. Pass --cli.')
        shutil.copyfile(ROOT / 'firmware/sesame-main/workshop-usb.h', ROOT / 'firmware/sesame-tester/workshop-usb.h')
        for kind in ['tester', 'main']:
            command = [args.cli, 'compile', '--fqbn', FQBN, '--build-path', str(build_root / f'build-{kind}')]
            if args.config: command += ['--config-file', args.config]
            subprocess.run(command + [str(ROOT / f'firmware/sesame-{kind}')], check=True)
    package_builds(build_root, arduino_data)
