# Sesame 制作工坊

LOLIN S2 Mini / ESP32-S2 的中文制作教材。采用选定的 A 制作工坊界面。

## 本地打开

安装 Python 3 后，双击 `启动网站.cmd`，或在本目录运行 `python serve.py --open`，在桌面 Chrome 或 Edge 打开 `http://127.0.0.1:8765`。网页串口需要 HTTPS 或 localhost，直接双击 HTML 无法完整使用。

网站本身为静态文件，部署目录为 `dist/`。课程、视频、打印件、固件和烧录库均随目录提供。本地阅读和烧录无需从 CDN 加载脚本。课程、物料与关键验证记录保存在当前浏览器。9 章为图文制作指导，第 02 章以物料表和打印件验收核对，第 03 章按五步完成接线与测量，其余验证集中在 4 个关键关卡；每关包含判定标准、检查方法、常见错误和返工提示。实物照片可选添加，使用 IndexedDB 保存在本浏览器，支持 JPG、PNG 和 WebP、单张不超过 8 MB。

## 烧录与验证

1. 打开烧录与调试，选择舵机测试固件或完整机器人程序，准备网页烧录。
2. 选择串口并按安装器提示写入。固件仅匹配 ESP32-S2。保留校准时不要选择 Erase device。
3. 关闭安装器，按开发板 RST，再连接并识别运行态串口。下载模式和运行模式可能为不同端口。
4. 托起机身，先在轴可自由转动时验证单个舵机。网页连接不会自动驱动。
5. 校准偏移在完整程序下设置，保存到 NVS 后，重启再读取核对。

安装器沿用 ESP Web Tools 的设备识别、写入进度、校验和错误日志界面，部分操作提示为英文。不要让 Arduino 串口监视器和网页同时占用串口。

### 停止行为

“停止动作并保持”取消动作序列并保持当前 PWM 目标。“释放全部舵机 PWM”同时 detach 舵机，仍需通过电源开关物理断电。USB 验证会话心跳间隔 400ms，固件超过 1500ms 未收到心跳后取消当前动作并保持输出。网页后台节流也可能触发该行为，重新连接后才恢复控制。

固件会在动画等待和舵机输出点检查 USB 指令。250ms 为设计响应目标，尚未实测。完整程序的 Wi-Fi 接口在 USB 验证会话期间返回 423，结束会话后恢复。

## 固件与复现

测试和完整程序均使用 `esp32:esp32:lolin_s2_mini:CDCOnBoot=default,PartitionScheme=default`。开发板包 Arduino-ESP32 3.3.10，ESP32Servo 3.0.9，另需 Adafruit SSD1306、GFX 与 BusIO。

`firmware/` 包含完整源代码。`build-firmware.py` 调用 Arduino CLI 编译并按实际产物生成两段烧录文件，避开 `0x9000–0xe000` 的 NVS。实际工具目录不同的电脑可传入 `--cli`、`--config` 和 `--data`。例如 `python build-firmware.py --cli "你的 arduino-cli 路径" --data "你的 Arduino15 目录"`。脚本需要 esptool 5.3.0 或 PATH 中的 esptool 5.x。

`dist/firmware/release.json` 记录固件版本、FQBN、字节数和 SHA-256。`source.zip` 为源码包。主动整片擦除或改变分区表会清除已有校准，正常分段更新不覆盖 NVS。

## 验证范围

固件已通过实际编译。网站提供真实串口和固件安装路径。当前交付未连接实板完成 USB 烧录、角度校准、停止延时或行走验收。网页回执只证明固件处理了命令，普通 MG90S 没有提供真实角度回读。

## 内容与许可

原项目由 Dorian Todd 创建，源代码与图片来自用户提供的 sesame-robot-main 本地版本。视频、3D 打印件与实购物料清单来自用户提供的 D 盘制作资料。完整步骤结合这些资料整理，视频描述依据画面检查，费用为原始记录。

- 原项目 https://github.com/dorianborian/sesame-robot
- 原项目 Apache-2.0 许可见 LICENSE 与 dist/assets/LICENSE，固件源码包同样包含 LICENSE
- ESP Web Tools 10.1.1 见 dist/vendor/LICENSE-ESP-Web-Tools
- 库的其他许可声明保留在 dist/vendor/THIRD-PARTY-LICENSES.txt

## 四个关键验证

51 个制作步骤保留为图文指导。第 02 章直接通过物料确认表与打印件验收完成核对，第 03 章按五步完成接线与测量，其余验证放在 4 个关键节点：

1. 测试固件与 8 舵机回中（第 06 章后）
2. 关节角度 Stand 45° / Rest 平行（第 07 章后）
3. 合盖前走线与开关（第 08 章后）
4. 整机动作验收（第 09 章后）

每关逐项勾选、填写实际结果后才能确认通过；修改勾选或文字后恢复待验证。视频演示正确样子和常见错误，是否通过仍以实物对照为准。`dist/checkpoints.js` 是关卡定义，`dist/verification-view.js` 渲染关卡，`dist/verification-state.js` 判定通过。

### 验证与调节视频工程

`videos/checkpoints/` 为 HyperFrames 工程（不随网站 zip 分发）。`scenes.mjs` 保留历史六关场景，`node build.mjs` 生成对应的 `compositions/*.html`；需要实拍照片的关卡在照片缺失时自动跳过。照片放入 `assets/photos/` 后重新构建即可。渲染：`hyperframes render -c compositions/k1.html -o k1.mp4`。第 03 章调压示例为独立的 `videos/buck-adjust/` HyperFrames 工程，使用用户提供的模块商品图与方向说明，万用表读数为明确标注的动画。首页介绍视频截取自原作者 YouTube 演示（1UDsWkcQZhc）的 0–22 秒。
